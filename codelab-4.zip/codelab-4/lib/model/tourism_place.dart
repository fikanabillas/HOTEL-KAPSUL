class TourismPlace {
  String name;
  String location;
  String description;
  String openDays;
  String openTime;
  String ticketPrice;
  String imageAsset;
  List<String> imageUrls;

  TourismPlace({
    required this.name,
    required this.location,
    required this.description,
    required this.openDays,
    required this.openTime,
    required this.ticketPrice,
    required this.imageAsset,
    required this.imageUrls,
  });
}

var tourismPlaceList = [
  TourismPlace(
    name: 'Whiz Capsule Hotel Thamrin',
    location: 'Jakarta',
    description:
        'Terletak di pusat kota Jakarta, hotel ini cocok untuk backpacker atau pelancong bisnis yang mencari penginapan terjangkau dan strategis. ',
    openDays: 'Open Everyday',
    openTime: '09:00 - 00:00',
    ticketPrice: 'Rp 250.000',
    imageAsset: 'images/tamrin1.jpg',
    imageUrls: [
      'images/tamrin2.jpg',
      'images/tamrin3.jpg',
      'images/tamrin4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Bobobox Pods',
    location: 'Berbagai Kota di Indonesia',
    description:
        'Jaringan hotel kapsul dengan desain futuristik, tersedia di Jakarta, Bandung, Bali, dan beberapa kota lainnya. Bobobox menawarkan pengalaman menginap dengan teknologi canggih seperti kontrol pencahayaan dan pintu berbasis aplikasi.',
    openDays: 'Open Tuesday - Saturday',
    openTime: '09:00 - 23:30',
    ticketPrice: 'Rp 200.000',
    imageAsset: 'images/bbx1.jpg',
    imageUrls: [
      'images/bbx2.jpg',
      'images/bbx3.jpg',
      'images/bbx4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Digital Airport Hotel',
    location: 'Jakarta',
    description:
        'Berlokasi di Terminal 3 Bandara Soekarno-Hatta, hotel ini ideal untuk transit. Setiap kapsul dilengkapi fasilitas modern seperti lampu baca, colokan USB, dan AC.',
    openDays: 'Open Everyday',
    openTime: '24 hours',
    ticketPrice: 'Free',
    imageAsset: 'images/hatta2.jpg',
    imageUrls: [
      'images/hatta1.jpg',
      'images/hatta3.jpg',
      'images/hatta4.jpg',
    ],
  ),
  TourismPlace(
    name: 'The Capsule Gajahmada',
    location: 'Jakarta',
    description:
        'Hotel kapsul yang terletak di kawasan strategis Jakarta Pusat. Menyediakan fasilitas nyaman dengan harga ekonomis.',
    openDays: 'Open Everyday',
    openTime: '06:00 - 00:00',
    ticketPrice: 'Rp 300.000',
    imageAsset: 'images/gm1.jpg',
    imageUrls: [
      'images/gm2.jpg',
      'images/gm3.jpg',
      'images/gm4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Dreamtel Capsule Hotel',
    location: 'Semarang',
    description:
        'Hotel kapsul dengan desain unik dan modern, berlokasi strategis dekat Simpang Lima. Menyediakan kenyamanan dengan fasilitas lengkap, seperti Wi-Fi gratis, AC, dan area komunal. Cocok untuk pelancong yang ingin menjelajahi Semarang dengan budget terbatas.',
    openDays: 'Open Everyday',
    openTime: '24 hours',
    ticketPrice: '350.000',
    imageAsset: 'images/semarang1.jpg',
    imageUrls: [
      'images/semarang2.jpg',
      'images/semarang3.jpg',
      'images/semarang4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Mypodroom Capsule Hotel',
    location: 'Bali',
    description:
        'Hotel kapsul dengan suasana santai khas Bali. Terletak dekat dengan area wisata seperti pantai dan pusat hiburan.',
    openDays: 'Open Saturday - Thursday',
    openTime: '09:00 - 23:30',
    ticketPrice: 'Rp 300.000',
    imageAsset: 'images/bali1.jpg',
    imageUrls: [
      'images/bali2.jpg',
      'images/bali2.jpg',
      'images/bali4.jpg',
    ],
  ),
  TourismPlace(
    name: 'KINI Luxury Capsule',
    location: 'Bali',
    description:
        'Hotel kapsul yang mengusung konsep mewah namun tetap terjangkau. Berlokasi strategis di Denpasar, cocok untuk pelancong muda.',
    openDays: 'Open Everyday',
    openTime: '09:00 - 23:00',
    ticketPrice: 'Rp 200.000',
    imageAsset: 'images/luxury1.jpg',
    imageUrls: [
      'images/luxury2.jpg',
      'images/luxury3.jpg',
      'images/luxury4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Capsule Inn Bali',
    location: 'Bali',
    description:
        'Berlokasi di Kuta, hotel kapsul ini menjadi favorit para backpacker karena dekat dengan pantai dan kehidupan malam Bali.',
    openDays: 'Open Everyday',
    openTime: '07:00 - 23:30',
    ticketPrice: 'Rp 150.000',
    imageAsset: 'images/inn1.jpg',
    imageUrls: [
      'images/inn2.jpg',
      'images/inn3.jpg',
      'images/inn4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Pod House',
    location: 'Makassar',
    description:
        'Hotel kapsul pertama di Makassar. Memberikan pengalaman menginap dengan desain modern dan lokasi yang strategis.  ',
    openDays: 'Open Everyday',
    openTime: '24 hours',
    ticketPrice: 'Rp 200.000',
    imageAsset: 'images/pod1.jpg',
    imageUrls: [
      'images/pod2.jpg',
      'images/pod3.jpg',
      'images/jkt4.jpg',
    ],
  ),
];
